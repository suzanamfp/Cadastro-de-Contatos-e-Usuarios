

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Contato;


@WebServlet("/CadastroContatoServlet")
public class CadastroContatoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private Contato contato;
	private List<Contato> listaContatos;
	
	public CadastroContatoServlet() {
		this.contato  = new Contato();
		this.listaContatos = new ArrayList<Contato>();
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nome            = request.getParameter("nome");
		String email           = request.getParameter("email");
		String telefone        = request.getParameter("telefone");
		String endereco        = request.getParameter("endereco");
		String senha           = request.getParameter("senha");
		
			
		this.contato.setNome(nome);
		this.contato.setEmail(email);
		this.contato.setTelefone(telefone);
		this.contato.setEndereco(endereco);
		this.contato.setSenha(senha);
		
		
		
		if (!validarEmail(email) && (!validarTelefone(telefone))) {
			this.listaContatos.add(this.contato);
			this.contato = new Contato(); 
			request.setAttribute("contatos", this.listaContatos );
			RequestDispatcher rd = request.getRequestDispatcher("listaContato.jsp");
			rd.forward(request, response);	
		}else{
			request.setAttribute("erro", "Campos de e-mail e telefone j� existem!" );
			RequestDispatcher rd = request.getRequestDispatcher("erro.jsp");
			rd.forward(request, response);
		}	
		
		}
	
		public boolean validarEmail(String email) {
			if(email.equals(null)) {
				return false;
			}
			for (Contato contato : listaContatos) {
				if(email.equals(contato.getEmail())){
					return true;
				}
			}
			return false;
			
		}
		
		public boolean validarTelefone(String telefone) {
			if(telefone.equals(null)) {
				return false;
			}
			for (Contato contato : listaContatos) {
				if(telefone.equals(contato.getTelefone())){
					return true;
				}
			}
			return false;
			
		}
			
				
}
	
